package com.cafepos.printing;

public interface Printer {
    void print(String receiptText);
}


