public interface Priced {
    Money price();
}

