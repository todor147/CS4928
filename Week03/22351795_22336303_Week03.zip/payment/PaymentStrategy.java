public interface PaymentStrategy {
    void pay(Order order);
}